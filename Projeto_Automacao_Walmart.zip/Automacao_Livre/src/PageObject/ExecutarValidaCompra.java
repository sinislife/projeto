package PageObject;

public class ExecutarValidaCompra {

	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Valida_Pesquisa valida_Pesquisa = new Valida_Pesquisa();		
		valida_Pesquisa.executar();
		
		
		
	}

}
